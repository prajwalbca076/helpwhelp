from django.db import models
# Create your models here.

class User(models.Model):
    username = models.CharField(max_length=10)
    fname = models.CharField(max_length=20)
    lname = models.CharField(max_length=20)
    email = models.EmailField(max_length=30)
    phone = models.IntegerField()
    password = models.CharField(max_length=20)
    active = models.BooleanField(default=False)
    admin = models.BooleanField(default=False)

class Whelp(models.Model):
    whelp_id = models.CharField(max_length=10)
    name = models.CharField(max_length=20)
    users = models.ForeignKey(User, related_name='username_user', on_delete=models.CASCADE)
    age = models.IntegerField()
    image = models.ImageField()

class Post(models.Model):
    post_id = models.CharField(max_length=10)
    description = models.CharField(max_length=300)
    posted_by = models.ForeignKey(User, related_name='username_user', on_delete=models.CASCADE)
    whelps = models.ForeignKey(Whelp, related_name='name_whelp', on_delete=models.CASCADE)
    image = models.ForeignKey(Whelp, on_delete=models.CASCADE)
    age = models.SmallIntegerField()
    posted_on = models.DateField()

    status_pub = 'y'
    status_unpub = 'n'
    status_choices = ((status_pub,'published'), (status_unpub, 'unpublished'))

    status = models.CharField(max_length=1, choices=status_choices)



from django.urls import path
from django.contrib import admin

from schoolproject import views

urlpatterns = [
    path('', views.home),
    path('signup/', views.signup),
    path('login/', views.login),
    path('admin/', admin.site.urls),
]

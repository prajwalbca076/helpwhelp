CREATE TABLE users (
    user_id int(5) NOT NULL AUTO_INCREMENT,
    user_name VARCHAR(10) NOT NULL,
    first_name varchar(64) NOT NULL,
    last_name varchar(64) NOT NULL,
    email varchar(64) NOT NULL,
    phone_number char(10) NOT NULL,
    password varchar(64) NOT NULL,
    is_active number(1),
    is_admin  number(1),
    CONSTRAINT pk_user_id PRIMARY KEY (user_id)
);

CREATE TABLE whelps (
    whelp_id int(5) NOT NULL AUTO_INCREMENT,
    name varchar(64) NULL,
    age varchar(64) NOT NULL,
    picture blob NULL,
    user_id int(5),
    CONSTRAINT pk_whelp_id PRIMARY KEY (whelp_id),
    CONSTRAINT fkw_user_id FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE post (
    post_id int(5) NOT NULL AUTO_INCREMENT,
    image blob NULL,
    description  varchar(100),
    whelp_id  int(5),
    posted_by varchar(64) NOT NULL,
    posted_on datetime NOT NULL,
    status number(1),
    CONSTRAINT pk_post_id PRIMARY KEY (post_id),
    CONSTRAINT fkp_user_id FOREIGN KEY (posted_by) REFERENCES users(user_id),
    CONSTRAINT fkp_whelps_id FOREIGN KEY (whelp_id) REFERENCES whelps(whelp_id),
    CONSTRAINT fkp_img FOREIGN KEY (image) REFERENCES whelps(picture)

);

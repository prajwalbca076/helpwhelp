from django.contrib.auth.hashers import make_password
from django.shortcuts import render, redirect
from .models import User
from .models import Whelp
from .forms import SignupForm, LoginForm, WhelpsForm, AdopterForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User


def home(request):
    return render(request, 'home.html', {})


def posts(request):
    post = Whelp.objects.raw("""SELECT * FROM schoolproject_adopter 
        AS A INNER JOIN schoolproject_whelp AS B ON A.username=B.user;""")
    return render(request, 'posts.html', {
        'posts': post
    })


def signup(request):
    if request.method == "POST":
        form = SignupForm(request.POST or None)
        adopter = AdopterForm(request.POST or None)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            password = form.cleaned_data['password']
            user = User.objects.create(
                username=username,
                password=make_password(password),
                email=email
            )
            user.phone = phone
            user.save()
            adopter.save()
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request, 'Signed up successfully!')
            return redirect('home')
        else:
            print(form.errors)
            username = request.POST['username']
            email = request.POST['email']
            phone = request.POST['phone']
            messages.success(request, "There's error in entered data")
            return render(request, 'signup.html', {
                'username': username,
                'email': email,
                'phone': phone
            })
    else:
        return render(request, 'signup.html', {})


def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            form = LoginForm(request.POST or None)
            username = request.POST['username']
            messages.success(request, 'There was an error logging in try again.')
            print(form.errors)
            return render(request, 'login.html', {'username': username})
    else:
        return render(request, 'login.html', {})


def user_logout(request):
    logout(request)
    return redirect('user_login')


def create_post(request):
    form = WhelpsForm(request.POST, request.FILES)
    if form.is_valid():
        post = form.save(commit=False)
        post.user = request.user.username
        post.save()
        messages.success(request, "Post created successfully")
        return redirect('home')
    else:
        messages.success(request, "Post couldn't be created. Internal Errors")
        for error in form.errors:
            print(error)
        return redirect('posts')


def not_found(request, exception):
    return render(request, '404.html')

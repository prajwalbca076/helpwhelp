from django.contrib import admin
from .models import Whelp, User
# Register your models here.

admin.site.register(Whelp)
admin.site.register(User)

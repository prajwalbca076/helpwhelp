from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('home', views.home, name="home"),
    path('signup', views.signup, name="signup"),
    path('user_login', views.user_login, name="user_login"),
    path('user_logout', views.user_logout, name="user_logout"),
    path('create_post', views.create_post, name="create_post"),
    path('posts', views.posts, name="posts"),
]

handler404 = "schoolproject.views.not_found"
